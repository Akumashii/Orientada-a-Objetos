package exer2;

import java.util.Scanner;

public class Exer2 {

	public static void main(String[] args) {
		String marca;
		String modelo;
		String tipo;
		double preco;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("digite a marca do notebook:");
		marca = sc.nextLine();
		System.out.println("digite o modelo do notebook:");
		modelo = sc.nextLine();
		System.out.println("digite o tipo(notebook, netbook, tablet, etc) do notebook:");
		tipo = sc.nextLine();
		System.out.println("digite o preco do notebook:");
		preco = sc.nextDouble();
		
		Computador c1 = new Computador();
		c1.marca = marca;
		c1.modelo = modelo;
		c1.tipo = tipo;
		c1.preco = preco;
		Computador c2 = new Computador();
		c2.marca = "Dell";
		c2.modelo = "Inspiron 15";
		c2.tipo = "notebook";
		c2.preco = 4500;
	
		System.out.println("Computador 1:");
		System.out.println("marca: "+c1.marca);
		System.out.println("modelo: "+c1.modelo);
		System.out.println("tipo: "+c1.tipo);
		System.out.println("preco: "+c1.preco);
		System.out.println("-------------------------------");
		System.out.println("Computador 2 (dados no codigo):");
		System.out.println("marca: "+c2.marca);
		System.out.println("modelo: "+c2.modelo);
		System.out.println("tipo: "+c2.tipo);
		System.out.println("preco: "+c2.preco);
	
		sc.close();
	}
}
