package exer1;

public class Exer1 {

	public static void main(String[] args) {
		Carro[] c = new Carro[2];
		
		for(int i=0; i<2; i++) { //instanciei o array de objetos
			c[i] = new Carro();
		}
		
		c[0].modelo = "fusca";
		c[0].marca = "volkswagen";
		c[0].anoFabricacao = 1959;
		
		c[1].modelo = "uno";
		c[1].marca = "fiat";
		c[1].anoFabricacao = 1983;
		
		System.out.println("Carro 1:");
		System.out.println(" - modelo: "+c[0].modelo);
		System.out.println(" - marca: "+c[0].marca);
		System.out.println(" - fabricação: "+c[0].anoFabricacao);
		
		System.out.println("---------------------");
		System.out.println("Carro 2:");
		System.out.println(" - modelo: "+c[1].modelo);
		System.out.println(" - marca: "+c[1].marca);
		System.out.println(" - fabricação: "+c[1].anoFabricacao);
		
	}

}
