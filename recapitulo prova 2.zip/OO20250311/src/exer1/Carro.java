package exer1;

public class Carro {
	public String marca;
	public String modelo;
	public int anoFabricacao;
}
