package exer4;

public class Exer4 {

	public static void main(String[] args) {
		Livro l = new Livro();
		
		l.titulo = "Pequeno Manual Antirracista";
		l.autor = "Djamila Ribeiro";
		l.anoPublicacao = 2019;
		
		System.out.println("Informações do Livro:");
		System.out.println(" - titulo: "+l.titulo);
		System.out.println(" - autor: "+l.autor);
		System.out.println(" - anoPublicação: "+l.anoPublicacao);
	}

}
