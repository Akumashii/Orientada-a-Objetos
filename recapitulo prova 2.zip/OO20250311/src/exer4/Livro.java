package exer4;

public class Livro {
	public String titulo;
	public String autor;
	public int anoPublicacao;
}
