package exer3;

public class Exer3 {

	public static void main(String[] args) {
		Pessoa pessoa = new Pessoa();
		pessoa.nome = "frazzon";
		pessoa.genero = "indefinido";
		pessoa.idade = 19;
		
		System.out.println("Informações Pessoais:");
		System.out.println(" - nome: "+pessoa.nome);
		System.out.println(" - genero: "+pessoa.genero);
		System.out.println(" - idade: "+pessoa.idade);
	}

}
