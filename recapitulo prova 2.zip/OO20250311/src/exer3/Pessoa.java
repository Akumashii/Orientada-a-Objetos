package exer3;

public class Pessoa {
	public String nome;
	public String genero;
	public int idade;
}
