package jogoRapido;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		Aluno a;
		
		String nome;
		double nota1, nota2;
		
		System.out.print("Digite o nome do Aluno: ");
		nome = scn.nextLine();
		System.out.print("Nota1: ");
		nota1 = scn.nextDouble();
		System.out.print("Nota2: ");
		nota2 = scn.nextDouble();
		
		a = new Aluno(nome, nota1, nota2);
				
		System.out.println("Nome: "+a.getNome());
		System.out.println("Media: "+a.mediaNota());
	
		scn.close();
	}

}
