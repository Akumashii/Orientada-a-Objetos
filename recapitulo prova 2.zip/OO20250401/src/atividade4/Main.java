package atividade4;

import java.util.Scanner;

/*
 * Crie uma classe Carro que possua os atributos marca, modelo e ano. 
 * Proteja os atributos utilizando encapsulamento. 
 * Crie os métodos get e set para cada atributo. 
 * Crie um método exibeDetalhes que exibe os detalhes do carro. 
 * Faça leitura pelo teclado dos valores
 * */
public class Main {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		Carro c = new Carro();
		
		System.out.print("Marca: ");
		c.setMarca(scn.nextLine());
		System.out.print("Modelo: ");
		c.setModelo(scn.nextLine());
		System.out.print("Ano: ");
		c.setAno(scn.nextInt());
		
		c.exibirDetalhes();
		
		scn.close();
	}

}
