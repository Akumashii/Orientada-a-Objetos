package atividade1;
/*
 * Crie uma classe ContaBancaria que possua os atributos saldo e limite. 
 * Proteja os atributos utilizando encapsulamento. 
 * Crie os métodos get e set para cada atributo. 
 * Crie um método saque que permita ao usuário sacar um valor da conta, desde que não ultrapasse o limite da conta. 
 * Faça leitura pelo teclado.
 */
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		ContaBancaria cb = new ContaBancaria();
		
		cb.setSaldo(1000);
		cb.setLimite(500);
		
		int op=1;
		do {
			System.out.println("Saldo: "+cb.getSaldo());
			System.out.println("Limite: "+cb.getLimite());

			System.out.println("Quanto deseja sacar: ");
			cb.sacar(scn.nextDouble());
			
			System.out.println("Continuar? (1 - sim // 2 - não): ");
			op = scn.nextInt();
			System.out.println("-----------------------");
		}while(op==1);
		
		scn.close();
	}

}
