package atividade1;

public class ContaBancaria {
	private double saldo;
	private double limite;
	
	public void sacar(double saque) {
		if(saque <= limite) {
			this.saldo = saldo - saque;
			this.limite = limite - saque;
			System.out.println("Saque bem sucedido!");
		}
		else {
			System.out.println("Estourou Limite!");
		}
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getLimite() {
		return limite;
	}

	public void setLimite(double limite) {
		this.limite = limite;
	}
	
	
	
}
