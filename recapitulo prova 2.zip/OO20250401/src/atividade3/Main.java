package atividade3;

import java.util.Scanner;

/*Crie uma classe Retangulo que possua os atributos base e altura. Proteja os atributos utilizando encapsulamento. 
 * Crie os métodos get e set para cada atributo. 
 * Crie um método calculaArea que calcule a área do retângulo e retorne o resultado. 
 * Faça leitura pelo teclado dos valores.
 * */

public class Main {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		Retangulo r = new Retangulo();
		System.out.println(" -=- Calcular Area Retangulo -=-");
		System.out.print("Digite a base: ");
		r.setBase(scn.nextDouble());
		System.out.print("Digite a altura: ");
		r.setAltura(scn.nextDouble());
		System.out.println("Area do respectivo retangulo: "+r.calculaArea());
		
		scn.close();
	}	
}
