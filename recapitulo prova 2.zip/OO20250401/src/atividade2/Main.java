package atividade2;
/*
 * Crie uma classe Circulo que possua o atributo raio. Proteja o atributo utilizando encapsulamento. 
 * Crie os métodos get e set para o atributo. X
 * Crie um método calculaArea que calcule a área do círculo e retorne o resultado. 
 * Faça leitura pelo teclado dos valores.
 */
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		Circulo c = new Circulo();
		
		System.out.println("Calculo area circulo: ");
		System.out.println("Digite o raio: ");
		c.setRaio(scn.nextDouble());
		System.out.println("Area do ciculo; "+c.calculaArea());;
		
		scn.close();
	}

}
