package encapsulamento;

public class Pessoa {
	private String nome;
	private int idade;
	private String cpf;
	
	public Pessoa(String nome, int idade, String cpf) {
		this.nome = nome;
		this.idade = idade;
		this.cpf = cpf;
	}
	
	public void apresentaDados() {
		System.out.println("Nome: "+nome);
		System.out.println("Idade: "+idade);
		System.out.println("CPF: "+cpf);
		System.out.println("----------------");
	}
	
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		if(idade>=0)
			this.idade = idade;
		else
			System.out.println("idade invalida");
	}
	public String getCpf() {
		return cpf;
	}
}
