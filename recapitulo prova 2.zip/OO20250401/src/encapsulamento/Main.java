package encapsulamento;

public class Main {

	public static void main(String[] args) {
		Pessoa p = new Pessoa("Frazzon",19,"05810776019");
		p.setIdade(19);
		p.apresentaDados();
		
		int idade, ano;
		idade = p.getIdade();
		ano = 2025 - idade;
		System.out.println("ano de nascimento: "+ano);
		p.apresentaDados();
		p.setIdade(-20);
		p.apresentaDados();
		
	}

}
