package atividade2;

import java.util.Scanner; 
import java.util.InputMismatchException;

public class Atividade2 {

	public static double calcular(double n1, double n2, int op){
		switch (op) {
	        case 1:
	            return n1 + n2;
	        case 2:
	            return n1 - n2;
	        case 3:
	            return n1 * n2;
	        case 4:
	            if (n2 == 0) {
	                throw new ArithmeticException("Divisão por zero não é permitida.");
	            }
	            return n1 / n2;
	        default:
	            throw new IllegalArgumentException("Operação não disponível. Inválida.");
		}
	}
		
	public static void main(String[] args) {
		double n1, n2;
		int op;
		
		Scanner scn = new Scanner(System.in);

		try {
			System.out.println("----- calculadora ------");
			System.out.println("1 - somar");
			System.out.println("2 - subtracao");
			System.out.println("3 - multiplicacao");
			System.out.println("4 - divisao");
			System.out.print("-> ");
			op = scn.nextInt();
			scn.nextLine(); //limpar buffer
			
			System.out.print("digite n1: ");
			n1 = scn.nextDouble();
			scn.nextLine(); 
			System.out.print("digite n2: ");
			n2 = scn.nextDouble();
			scn.nextLine(); 
			
			double r = calcular(n1,n2,op);
			System.out.println("Resultado: "+r);
			
		}catch(InputMismatchException e) { //é pra só detecta numero
			System.out.println("Erro: entrada inválida. Digite apenas números.");
			scn.nextLine();
		} catch (ArithmeticException e) {
            System.out.println("Erro: " + e.getMessage()); //passa a mensagem pra string
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }finally {
        	scn.close();

        }
			
	}

}
