package atividade4;
//4 – Pesquise quais são as Exceções existentes que já possuem tratamento e explique brevemente como cada uma funciona. Teste duas exceções.
//as principais sao NullPointerException, ArrayIndexOutOfBoundException, NumberFormatException, ArithmeticException, InputMismatchException

import java.util.InputMismatchException;
import java.util.Scanner;

public class Atividade4 
{

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = 0;
		System.out.println("Digite um número para fazer raiz quadrada: ");
		try{
			n = sc.nextInt();
			
			if(n < 0) {
				throw new IllegalArgumentException("Não é possível calcular raiz quadrada com número negativo"); //adicionando a mensagem do erro
			}
			//IllegalArgumentException serve para adicionar uma excecao para nao receber nenhum argumento invalido
			double raiz = Math.sqrt(n);
			System.out.println("Raiz quadrada de "+n+" = "+raiz);
			
		}catch(InputMismatchException e){ //Quando o usuário digita um valor que não corresponde ao tipo esperado
			System.out.println("Exceção: "+e.toString());
		}catch(IllegalArgumentException e) {
			System.out.println("Exceção: "+e.toString());
		}finally {
			sc.close(); 
		}

		
	}

}