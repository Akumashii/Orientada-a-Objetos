package atividade3;
//3 – Faça o tratamento de exceções em conversões de valores lidos pelo teclado. Por exemplo, ao ler uma string e converter ela para double.
import java.util.Scanner;


public class Atividade3 {

	public static void main(String[] args) {
		String str;
		double dbl;
		Scanner scn = new Scanner(System.in);
		
		try {
			System.out.println("Digite um numero decimal: ");
			str = scn.nextLine();
			
			dbl = Double.parseDouble(str);
			
			System.out.println("Valor digitado formato String para double: "+dbl);
		}catch(NumberFormatException e) {
			System.out.println("Erro: "+e.getMessage());
		}finally {
			scn.close();
		}
				
	}

}
