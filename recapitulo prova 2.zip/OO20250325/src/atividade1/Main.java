/*
 * Escreva um programa que solicita ao usuário para digitar um número inteiro e exiba a raiz quadrada desse número. 
 * Certifique-se de que o programa trate adequadamente as exceções se o usuário digitar um valor inválido, por exemplo, ler um char ou string.
 * */
package atividade1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = 0;
		System.out.println("Digite um número para fazer raiz quadrada: ");
		try{
			n = sc.nextInt();
			
			if(n < 0) {
				//aqui to lancando uma exceção manualmente pra detectar numeros negativos para nao complicar minha vida com a raiz
				throw new IllegalArgumentException("Não é possível calcular raiz quadrada com número negativo"); //adicionando a mensagem do erro
			}
			
			double raiz = Math.sqrt(n);
			System.out.println("Raiz quadrada de "+n+" = "+raiz);
			
		}catch(InputMismatchException e){
			System.out.println("Exceção: "+e.toString());
		}catch(IllegalArgumentException e) {
			System.out.println("Exceção: "+e.toString());
		}finally {
			sc.close(); //aparentemente preciso do finally pra poder fechar o scan idependente do que ocorra dentro do try e se ele estivesse fora talvez nao compilaria
		}

		
	}

}
