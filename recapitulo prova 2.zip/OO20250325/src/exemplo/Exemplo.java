package exemplo;

public class Exemplo {

	public static void main(String[] args) {
		int a=0, b=0;
		try{
			System.out.println(a/b);
		}catch (ArithmeticException e) {
			System.out.println("Exceção: "+e.getMessage());
			System.out.println("Exceção: "+e.toString());
		}
		System.out.println("programa segue em execução");
	}

}
