package atividade1;

import java.util.Scanner;

/*
Crie uma classe Produto com os atributos:
nome (String)
preco (double)
quantidade (int)
Implemente:
Um método exibirInformacoes() que exibe os dados do produto
Um método calcularValorTotal() que retorna o valor total em estoque (preço x quantidade)
Na Main
Crie dois produtos, sendo um com valores informados via teclado e outro com valores definidos no código
Exiba as informações e o valor total de cada produto
 * 
 * */
public class Main {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		Produto p1 = new Produto();
		Produto p2 = new Produto();
		
		p1.setNome("Bombom");
		p1.setPreco(3.99);
		p1.setQuantidade(8);
		
		System.out.println("Insira o Produto");
		System.out.print("Nome: "); p2.setNome(scn.nextLine());
		System.out.print("Preço: "); p2.setPreco(scn.nextDouble());
		System.out.print("Quantidade: "); p2.setQuantidade(scn.nextInt());
		
		p1.exibirInformacoes();
		p2.exibirInformacoes();
		
		scn.close();
	}

}
