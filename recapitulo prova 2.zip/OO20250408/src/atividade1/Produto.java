package atividade1;

public class Produto {
	private String nome;
	private double preco;
	private int quantidade;
	
	public double calcularValorTotal() {
		return preco*quantidade; 
	}
	
	public void exibirInformacoes() {
		System.out.println("\n-=-=-=-=-=-=-=-=-=-");
		System.out.println("Nome: "+nome);
		System.out.println("Preço: "+preco);
		System.out.println("Quantidade: "+quantidade);
		System.out.println("Valor total em estoque: "+calcularValorTotal());
		System.out.println("-=-=-=-=-=-=-=-=-=-");
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
}
