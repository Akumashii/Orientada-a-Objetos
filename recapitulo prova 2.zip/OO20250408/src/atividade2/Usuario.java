package atividade2;

public class Usuario {
	private String nomeUsuario;
	private String senha;
	private boolean logado;
	
	public void login(String nomeUsuario, String senha) {
		if(logado == false) {
			if(this.nomeUsuario == nomeUsuario) {
				if(this.senha == senha) {
					logado = true;
				}else {
					System.out.println("Senha Errada!");
				}
			}else {
				System.out.println("Nome de Usuario Errado!");
			}
		}else{
			System.out.println("Usuario Já Logado!");
		}
	}
	
	public void logout() {
		logado = false;
	}
	
	public void exibirStatus() {
		System.out.println("Status: "+logado);;
	}
	
	public String getNomeUsuario() {
		return nomeUsuario;
	}
	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public boolean isLogado() {
		return logado;
	}
	public void setLogado(boolean logado) {
		this.logado = logado;
	}
	
}
