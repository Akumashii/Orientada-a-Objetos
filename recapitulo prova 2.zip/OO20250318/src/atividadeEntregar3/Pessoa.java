package atividadeEntregar3;

public class Pessoa {
	String nome;
	String email;
	String endereco;
	String dataNascimento;
	boolean admin;
	
	public Pessoa(String nome, String email, String endereco, String dataNascimento) {
		this.nome = nome;
		this.email = email;
		this.endereco = endereco;
		this.dataNascimento = dataNascimento;
		this.admin = false;
	}	
	
	public void exibirEmail() {
		System.out.println(nome+" email: "+email);
	}
	
	public void promoverAdmin() {
		this.admin = true;
		System.out.println(nome+" agora é um admin.");
	}
	
}
