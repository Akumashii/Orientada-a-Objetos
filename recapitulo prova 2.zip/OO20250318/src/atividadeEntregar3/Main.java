/*
 * 3) Crie uma classe chamada Pessoa. Nesta classe deve conter os atributos: Nome, email, data de nascimento, Endereço e o atributo Admin do tipo booleano. 
 * Crie um método que retorne o Email da pessoa. 
 * Crie um método chamado promoverAdmin que ao ser chamado altera o atributo Admin. 
 * Faça a leitura de duas pessoas na main e mantenha uma como admin e outra não.
*/
package atividadeEntregar3;

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		List<Pessoa> p = new ArrayList<>();
		
		String nome;
		String email;
		String endereco;
		String dataNascimento;
		
		Pessoa pessoa;
		
		for(int i=0; i<2; i++) {
			System.out.println("Dados da pessoa "+(i+1)); //scaneando dados
			System.out.println("Nome:");
			nome = sc.nextLine();
			System.out.println("Email:");
			email = sc.nextLine();
			System.out.println("Endereço:");
			endereco = sc.nextLine();
			//data nascimento é diferente
			String ano, mes, dia;
			System.out.println("Data de Nascimento"); //show de bola
			System.out.println("Ano: ");
			ano = sc.nextLine();
			System.out.println("Mês: ");
			mes = sc.nextLine();
			System.out.println("Dia: ");
			dia = sc.nextLine();
			dataNascimento = ano+"-"+mes+"-"+dia; //formatando data de nascimento
			//nota: nem precisava printar isso pq eu bati tanto a cabeça ;c
			pessoa = new Pessoa(nome, email, endereco, dataNascimento);
		
			System.out.println("Deseja promover este usuário para Administrador? (1 - sim // 2 - nao) ");
			int op = 0;
			op = sc.nextInt();
			sc.nextLine(); //limpar \n
			if(op==1) {
				pessoa.promoverAdmin();
			}
			else {
				System.out.println("Usuário não promovido.");
			}
			System.out.println("-------------------------");
			
			p.add(pessoa);
		}
		
		System.out.println("\n\n\n");
		System.out.println("-------------------------");
		for(Pessoa i : p) {
			i.exibirEmail();
			if(i.admin) {
				System.out.println("email Administrador");
				
			}
			System.out.println("-------------------------");
		}
		
		sc.close();
	}

}
