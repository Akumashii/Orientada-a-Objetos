/*
1) Crie uma classe Disciplina que contenha os atributos (nome, carga horária e nome do professor) e os métodos de atribuir e recuperar esses valores. Mostre na tela:
a) O conteúdo original dos atributos
b) A opção para o usuário inserir os valores
c) A exibição do novo conteúdo dos atributos
 */
package atividadeEntregar;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Disciplina disciplina = new Disciplina();
		
		disciplina.exibirDados();
		
		System.out.println("digite nome da disciplina:");
		String nome = sc.nextLine();
		System.out.println("digite nome professor:");
		String nomeProfessor = sc.nextLine();
		System.out.println("digite carga horaria professor:");
		int cargaHoraria = sc.nextInt();
		System.out.println("--------------------");
		
		disciplina.atribuir(nome, nomeProfessor, cargaHoraria);
		
		disciplina.exibirDados();
		
		sc.close();
	}
}
