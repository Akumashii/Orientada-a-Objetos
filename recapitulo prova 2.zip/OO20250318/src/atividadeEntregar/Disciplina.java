package atividadeEntregar;

public class Disciplina {
	public String nome;
	public String nomeProfessor;
	public int cargaHoraria;
		
	public Disciplina() {
		this.nome = "História";
		this.nomeProfessor = "Décio";
		this.cargaHoraria = 40;
	}
	
	public void atribuir(String nome, String nomeProfessor, int cargaHoraria) {
		this.nome = nome;
		this.nomeProfessor = nomeProfessor;
		this.cargaHoraria = cargaHoraria;
	}
	
	public void exibirDados() {
		System.out.println("Disciplina: "+nome);
		System.out.println("Professor: "+nomeProfessor);
		System.out.println("Carga Horária: "+cargaHoraria+"h");
		System.out.println("--------------------");
	}
	
}
