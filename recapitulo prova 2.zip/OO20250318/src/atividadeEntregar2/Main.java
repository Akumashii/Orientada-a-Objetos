/*
 * 2) Crie uma classe chamada Livro que contenha os atributos Título, Autor, Ano de publicação, Gênero e Emprestado (bool). 
 * Crie método que retorne as informações do livro. 
 * Crie também um método responsável por fazer o empréstimo do livro e outro para fazer a devolução. 
 * Faça o controle disto utilizando o atributo Emprestado.
 * */

package atividadeEntregar2;

public class Main {

	public static void main(String[] args) {
		Livro l = new Livro();
		
		l.exibirDados();
		
		l.emprestar();
		l.emprestar();

		l.exibirDados();

		
		l.devolver();
		l.devolver();
		
		l.exibirDados();
	}

}
