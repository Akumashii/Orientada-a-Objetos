package atividadeEntregar2;

public class Livro {
	String titulo;
	String autor;
	String genero;
	int anoPublicacao;
	boolean emprestado;
	
	public Livro() {
		this.titulo = "Terraria";
		this.autor = "Frazzon";		
		this.genero = "Romance";
		this.anoPublicacao = 2025;
		this.emprestado = false;
	}
	
	public boolean verificaEmprestado() {
		return emprestado;
	}
	
	public void emprestar() {
		if(!verificaEmprestado()) {
			emprestado = true;
			System.out.println("Livro emprestado com sucesso!");
		}else {
			System.out.println("Livro já está sendo ocupado!");
		}
	}
	
	public void devolver() {
		if(verificaEmprestado()) {
			emprestado = false;
			System.out.println("Livro devolvido com sucesso!");
		}else {
			System.out.println("Livro já foi devolvido!");
		}
	}
	
	public void exibirDados() {
		System.out.println("-----------------------------");
		System.out.println("Título: "+titulo);
		System.out.println("Autor: "+autor);
		System.out.println("Gênero: "+genero);
		System.out.println("Ano de Publicação: "+anoPublicacao);
		System.out.println("Emprestado: "+emprestado);
		System.out.println("-----------------------------");
	}
}
