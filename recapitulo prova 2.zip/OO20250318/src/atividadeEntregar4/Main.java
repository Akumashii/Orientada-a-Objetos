/*
4) Crie uma classe ContaCorrente que obedeça à descrição abaixo:
A classe possui o atributo saldo do tipo float e os métodos definirSaldoInicial, depositar e sacar.

O método definirSaldoInicial deve atribuir o valor passado por parâmetro ao atribuito saldo
O método depositar, deve adicionar o valor passado por parâmetro ao atributo saldo
O método sacar deve reduzir o valor passado por parâmetro do saldo já existente

Necessário verificar a condição de o valor do saldo ser insuficiente para o saque que se deseja fazer.
O valor de retorno deve ser true (verdadeiro) quando for possível realizar o saque e false (falso) quando não for possível (public bool sacar(float valor))

Crie uma classe ContaCorrente que obedeça à descrição abaixo (continuação):
Crie um objeto novaConta do tipo ContaCorrente.
Chame o método definirSaldoInicial passando o valor 1000 como parâmetro.
Escreva o valor do atributo saldo
Realize um saque de 500 reais (utilize o método sacar).
Faça um depósito de 50 reais (utilize o método depositar)
Escreva o valor do atributo saldo na tela.
Realize um saque de 600 reais.
Escreva o valor do atributo saldo na tela
 * */
package atividadeEntregar4;

public class Main {

	public static void main(String[] args) {
		ContaCorrente novaConta = new ContaCorrente();
		
		//Chame o método definirSaldoInicial passando o valor 1000 como parâmetro.
		novaConta.definirSaldoInicial(1000);
		//Escreva o valor do atributo saldo
		novaConta.mostrarSaldo();
		//Realize um saque de 500 reais (utilize o método sacar).
		novaConta.sacar(500);
		//Faça um depósito de 50 reais (utilize o método depositar)
		novaConta.depositar(50);
		//Escreva o valor do atributo saldo na tela.
		novaConta.mostrarSaldo();
		//Realize um saque de 600 reais.
		novaConta.sacar(600);
		//Escreva o valor do atributo saldo na tela
		novaConta.mostrarSaldo();

	}

}
