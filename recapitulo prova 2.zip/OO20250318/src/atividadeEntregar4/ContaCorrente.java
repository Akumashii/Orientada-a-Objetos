//O método definirSaldoInicial deve atribuir o valor passado por parâmetro ao atribuito saldo
//O método depositar, deve adicionar o valor passado por parâmetro ao atributo saldo
//O método sacar deve reduzir o valor passado por parâmetro do saldo já existente

package atividadeEntregar4;

public class ContaCorrente {
    public float saldo; 

    public void definirSaldoInicial(float saldoInicial) {
        this.saldo = saldoInicial;
    }

    public void depositar(float valor) {
        this.saldo += valor;
    }

    public boolean sacar(float valor) {
        if (valor > this.saldo) {
            System.out.println("Saldo insuficiente para saque de R$" + valor);
            return false;
        }
        this.saldo -= valor;
        return true;
    }

    public void mostrarSaldo() {
        System.out.println("Saldo atual: R$" + this.saldo);
    }
}