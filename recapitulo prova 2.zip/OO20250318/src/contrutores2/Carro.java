package contrutores2;

public class Carro {
	public String marca;
	public String modelo;
	public boolean alugado;
	
	public Carro (String modeloCarro, String marcaCarro) { //parametros estabelecidos
		marca = marcaCarro;
		modelo = modeloCarro;
	}
	
	public boolean verificaAlugado() {
		return alugado;
	}
	void alugar() {
		if(!verificaAlugado()) {
			alugado = true;
			System.out.println("Carro Alugado!");
		}else {
			System.out.println("Carro não disponível para locação!");
		}
	}
	void devolver() {
		if(verificaAlugado()) {
			alugado = false;
			System.out.println("Carro Devolvido!");
		}else {
			System.out.println("Carro não alugado, não é possível devolução");
		}
	}
	
	public void exibirDados() { //voida para exibir, retorna nada
		System.out.println("Modelo: "+modelo);
		System.out.println("Marca: "+marca);
		System.out.println("Alugado: "+alugado);
	}
}

