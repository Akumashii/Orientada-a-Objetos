package contrutores2;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("digite o modelo:");
		String mo = sc.nextLine();
		System.out.println("digite a marca:");
		String ma = sc.nextLine();
		Carro c = new Carro(mo, ma);
		c.alugar();
		c.alugar();
		c.alugar();
		
		c.devolver();
		c.devolver();
		c.devolver();
		
		c.alugar();
		
		c.exibirDados();
		
		sc.close();
	}

}
