/*
 * 5) Criar uma classe chamada Pessoa com 2 construtores, um que receba o nome e a idade da pessoa e outro recebendo apenas a idade. 
 * Solicite ao usuário qual dos construtores ele gostaria de utilizar na instanciação da classe. 
 * Além de receber parâmetros, os construtores imprimem na tela o conteúdo dos parâmetros recebidos.
*/

package atividadeEntregar5;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		String nome;
		int idade;
		
		int op=1;
		System.out.println("Deseja instanciar qual classe?");
		System.out.println("(1 - Nome e Idade)");
		System.out.println("(2 - Idade)");
		System.out.print("Digite: ");
		op = sc.nextInt();
		sc.nextLine(); //evita problema com o \n
		if(op==1) {
			System.out.println("Nome:");
			nome = sc.nextLine();
			System.out.println("Idade:");
			idade = sc.nextInt();
			Pessoa pessoa = new Pessoa(nome, idade);
		}else if(op==2) {
			System.out.println("Idade:");
			idade = sc.nextInt();
			Pessoa pessoa = new Pessoa(idade);
		}else {
			System.out.println("Você digitou um valor inválido.");
		}
		
		sc.close();
	}

}
