package atividadeEntregar5;

public class Pessoa {
	String nome;
	int idade;
	
	public Pessoa (String nome, int idade) {
		this.nome = nome;
		this.idade = idade;
		System.out.println("Nome: "+nome);
		System.out.println("Idade: "+idade);
	}
	
	public Pessoa (int idade) {
		this.idade = idade;
		System.out.println("Idade: "+idade);
	}
}
