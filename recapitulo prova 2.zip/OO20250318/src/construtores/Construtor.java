package construtores;

import java.util.Scanner;

public class Construtor {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("digite o modelo:");
		String mo = sc.nextLine();
		System.out.println("digite a marca:");
		String ma = sc.nextLine();
		Carro c = new Carro(mo, ma);
		c.exibirDados();
		
		Carro c2 = new Carro("fodas");
		c2.marca = "FODAS";
		c2.exibirDados();
		
		Carro c3 = new Carro();
		c3.marca = "boboca";
		c3.modelo = "ridiculo";
		c3.exibirDados();
		
		sc.close();
	}

}
