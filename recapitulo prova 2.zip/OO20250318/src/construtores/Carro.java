package construtores;

public class Carro {
	public String marca;
	public String modelo;
	
	public Carro (String modeloCarro, String marcaCarro) { //parametros estabelecidos
		marca = marcaCarro;
		modelo = modeloCarro;
	}
	
	public Carro (String modeloCarro) { 
		modelo = modeloCarro;
	}
	
	public Carro () {
	}
	
	public void exibirDados() { //voida para exibir, retorna nada
		System.out.println("Modelo: "+modelo);
		System.out.println("Marca: "+marca);
	}
}

