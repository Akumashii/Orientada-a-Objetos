/*
 * 6) Criar uma classe chamada Aluno com 3 construtores, sendo que o primeiro recebe o nome e a matrícula do aluno,
 *  o segundo recebe apenas a data de nascimento do aluno e 
 *  o terceiro construtor recebe o nome do aluno, a data de nascimento e o ano em que o aluno ingressou na faculdade.
	Crie uma classe principal, com 3 objetos, cada um instanciando a classe com um construtor diferente.
*/
package atividadeEntregar6;

public class Main {

	public static void main(String[] args) {
        Aluno aluno1 = new Aluno("Guilherme Frazzon", 42069);
        Aluno aluno2 = new Aluno("20/01/2006");
        Aluno aluno3 = new Aluno("Ana Clara Senhor", "02/05/2006", 2024);

        aluno1.exibirInformacoes();
        aluno2.exibirInformacoes();
        aluno3.exibirInformacoes();
	}

}
