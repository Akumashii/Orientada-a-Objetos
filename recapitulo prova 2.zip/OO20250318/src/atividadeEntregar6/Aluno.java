package atividadeEntregar6;

public class Aluno {
    public String nome;
    public int matricula;
    public String dataNascimento;
    public int anoIngresso;

    public Aluno(String nome, int matricula) {
        this.nome = nome;
        this.matricula = matricula;
    }

    public Aluno(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public Aluno(String nome, String dataNascimento, int anoIngresso) {
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.anoIngresso = anoIngresso;
    }
  
    public void exibirInformacoes() {
        System.out.println("Aluno:");
        if (nome != null) 
        	System.out.println("Nome: " + nome);
        if (matricula != 0) 
        	System.out.println("Matrícula: " + matricula);
        if (dataNascimento != null) 
        	System.out.println("Data de Nascimento: " + dataNascimento);
        if (anoIngresso != 0) 
        	System.out.println("Ano de Ingresso: " + anoIngresso);
        System.out.println("---------------------------");
    }
}