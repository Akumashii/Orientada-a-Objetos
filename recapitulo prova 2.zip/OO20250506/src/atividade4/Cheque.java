package atividade4;

public class Cheque {
	public double saldo;
	
	public Cheque(double saldo) {
		this.saldo = saldo;
	}
}
