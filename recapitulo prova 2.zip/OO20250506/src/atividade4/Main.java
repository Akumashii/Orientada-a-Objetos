package atividade4;

public class Main {

	public static void main(String[] args) {
		Cheque c = new Cheque(500);
		ContaBancaria banco = new ContaBancaria();
		
		System.out.println("Saldo: "+banco.getSaldo());
		
		
		//pelo metodo valor um double
		System.out.println("depois de adicionar um valor");
		banco.depositar(500);
		System.out.println("Saldo: "+banco.getSaldo());
		
		
		//pelo metodo com objeto
		System.out.println("depois de adicionar o cheque...");
		banco.depositar(c);
		System.out.println("Saldo: "+banco.getSaldo());
	}

}
