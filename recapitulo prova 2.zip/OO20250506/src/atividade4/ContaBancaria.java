package atividade4;

public class ContaBancaria {
	protected double saldo;
	
	public ContaBancaria() {
		saldo = 0;
	}
	
	public void depositar(double valor) {
		saldo = saldo + valor;
	}
	
	public void depositar(Cheque c) {
		saldo = saldo + c.saldo;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	
}
