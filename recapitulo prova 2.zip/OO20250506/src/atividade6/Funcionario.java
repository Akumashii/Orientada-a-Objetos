package atividade6;

public class Funcionario {
	protected String nome;
	protected double salario;
	protected double percentagemAumentoSalarial;
	
	public Funcionario(String nome, double salario)
	{
		this.nome = nome;
		this.percentagemAumentoSalarial = (0.5*salario);
		this.salario = salario;
	}
	
	public void aumentarSalario()
	{
		salario = salario + percentagemAumentoSalarial;
	}
	
	@Override
	public String toString()
	{
		
		return "Nome: "+nome+" | Salário: "+salario;
	}
}
