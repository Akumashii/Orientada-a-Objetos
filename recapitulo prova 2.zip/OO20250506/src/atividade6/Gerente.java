package atividade6;

public class Gerente extends Funcionario{
	private double bonusAnual;
	
	public Gerente(String nome, double salario)
	{
		super(nome, salario); //oque mando pra bosta da classe pai fazer ele
		bonusAnual = (0.2*salario);
	}
	
	@Override
	public void aumentarSalario()
	{
		salario =  salario + percentagemAumentoSalarial + bonusAnual;
	}
	
	@Override
	public String toString()
	{
		return "Nome: "+nome+" | Salário: "+salario+" | Bônus Anual: "+bonusAnual; 
	}
}
