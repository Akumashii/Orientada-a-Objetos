package atividade6;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		ArrayList<Funcionario> funcionarios = new ArrayList<>();
		
		funcionarios.add(new Gerente("Frazzon", 1000));
		funcionarios.add(new Gerente("Ana Clara", 5000));

		funcionarios.add(new Desenvolvedor("Luiza", 1000, 10));
		funcionarios.add(new Desenvolvedor("Vanessa", 1000, 0));

		System.out.println("Antes:");
		for(Funcionario f : funcionarios)
		{			
			System.out.println(" - "+f.toString());
		}
		
		System.out.println("Depois: ");
		for(Funcionario f : funcionarios)
		{
			f.aumentarSalario();
			System.out.println(" - "+f.toString());
		}
	}

}
