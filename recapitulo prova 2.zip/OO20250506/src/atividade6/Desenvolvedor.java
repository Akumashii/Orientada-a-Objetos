package atividade6;

public class Desenvolvedor extends Funcionario{
	private int horaExtra;
	
	public Desenvolvedor(String nome, double salario, int horaExtra)
	{		 
		super(nome, salario);
		setHoraExtra(horaExtra);
	}
	
	public void aumentarSalario()
	{
		salario = salario + percentagemAumentoSalarial + (horaExtra*30);
	}
	
	@Override
	public String toString()
	{
		return "Nome: "+nome+" | Salário: "+salario+" | Hora Extra: "+horaExtra; 
	}

	public int getHoraExtra() {
		return horaExtra;
	}

	public void setHoraExtra(int horaExtra) {
		this.horaExtra = horaExtra;
	}
	
	
}
