package atividade8;

public class Reserva {
	protected boolean reserva;
	protected String tipoReserva;
	
	public Reserva() { //esse aqui é pra inicia só
		reserva = false;
	}
	
	public Reserva(boolean confirmacao) {
		adicionarReserva();
		setTipoReserva("Hotel");
	}
	
	public Reserva(String tipoReserva) 
	{
		adicionarReserva();
		setTipoReserva(tipoReserva);
	}
	
	public void adicionarReserva() 
	{
		System.out.println("========================================= reserve: "+isReserva());
		if(isReserva() == false) { //NAO FUNCIONAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
			setReserva(true);
			System.out.println("reserva adicionada!");
		}
		else 
		{
			System.out.println("reserva já adicionada");
		}
	}
	public void cancelarReserva() 
	{
		if(isReserva() == true) 
		{
			setReserva(false);
			setTipoReserva(null);
			System.out.println("reserva cancelada!");
		}
		else 
		{
			System.out.println("reserva já cancelada.");
		}
	}
	
	public void exibirDados() 
	{
		System.out.println("-=- info -=-");
		System.out.println("Status Reserva: "+isReserva());
		System.out.println("Tipo Reserva: "+getTipoReserva());
	}
		
	public boolean isReserva() {
		return reserva;
	}

	public void setReserva(boolean reserva) {
		this.reserva = reserva;
	}

	public String getTipoReserva() {
		return tipoReserva;
	}

	public void setTipoReserva(String tipoReserva) {
		this.tipoReserva = tipoReserva;
	}
	
	
}
