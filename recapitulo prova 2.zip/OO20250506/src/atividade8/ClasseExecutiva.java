package atividade8;

public class ClasseExecutiva extends ClasseVoo
{
	public ClasseExecutiva() {
		super("Executiva");
	}
}
