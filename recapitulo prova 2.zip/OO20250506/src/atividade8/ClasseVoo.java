package atividade8;

public class ClasseVoo {
	protected String classe;
	
	public ClasseVoo(String classe) {
		setClasse(classe);
	}

	public String getClasse() {
		return classe;
	}

	public void setClasse(String classe) {
		this.classe = classe;
	}
	
}
