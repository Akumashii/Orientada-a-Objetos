package atividade8;

import java.util.Scanner;

public class Main 
{

	public static void main(String[] args) 
	{
		Scanner scn = new Scanner(System.in);
		
		Reserva reserva = new Reserva();
		
		int op;
		while(true) 
		{
			System.out.println(" -=- Menu -=-");
			System.out.println("1 - Reserva Voo");
			System.out.println("2 - Reserva Hotel");
			System.out.println("3 - Exibir Detalhes Sobre a Reserva");
			System.out.println("4 - Cancelar Reserva");
			System.out.println("5 - Sair");
			System.out.print("->");
			op = scn.nextInt();
			switch(op) 
			{
				case 1:
					System.out.println("1 - Classe Econômica");
					System.out.println("2 - Classe Executiva");
					System.out.println("3 - Nenhum");
					System.out.print("->");
					op = scn.nextInt();
					
					if(op == 1)
					{
						ClasseVoo a = new ClasseEconomica();
						reserva = new ReservaVoo(a);						
					}
					else if(op == 2)
					{
						ClasseVoo a = new ClasseExecutiva();
						reserva = new ReservaVoo(a);
					}
					else
					{
						System.out.println("Voltando Menu...");
					}
					break;
					
				case 2:
					reserva = new ReservaHotel(true);
					break;
					
				case 3:
					reserva.exibirDados();
					break;
					
				case 4:
					reserva.cancelarReserva();
					break;
					
				case 5:
					System.out.println("Saindo...");
					return;
					
				default:
					System.out.println("Entrada Inválida... Tente Novamente");
					scn.close();
					break;
			}
		}
	}
}
