package atividade8;

public class ClasseEconomica extends ClasseVoo
{
	public ClasseEconomica() {
		super("Econômica");
	}
}
