package atividade8;

public class ReservaVoo extends Reserva
{
	
	public ReservaVoo(ClasseVoo a) 
	{
		super(a.getClasse());
	}
	
	@Override
	public void cancelarReserva() 
	{
		if(isReserva()) {
			setReserva(false);
			setTipoReserva("inválido");
			System.out.println("Reserva Cancelada. Reembolso Emitido.");
		}else
			System.out.println("reserva já cancelada.");
	}
}
