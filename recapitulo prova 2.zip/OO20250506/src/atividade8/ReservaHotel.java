package atividade8;

public class ReservaHotel extends Reserva{
	
	
	public ReservaHotel(boolean confirmacao)
	{
		super(true);
	}
	
	@Override
	public void cancelarReserva()
	{
		if(isReserva()) {
			setReserva(false);
			setTipoReserva("inválido");
			System.out.println("Reserva Cancelada. Cancelamento sujeito a multa.");
		}else
			System.out.println("reserva já cancelada.");
	}
}
