package atividade1;

import java.util.Scanner;

public class Notebook extends Computador{

	public Notebook(String marca) {
		super(marca);
	}
	
	public String exibeMarca() {
		return marca;
	}
	
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		
		System.out.print("Digite a marca do Notebook: ");
		String marca = scn.nextLine();
		
		Notebook note = new Notebook(marca);
		System.out.println("Modelo: "+note.exibeModelo());
		System.out.println("Marca: "+note.exibeMarca());
		
		scn.close();
	}

}
