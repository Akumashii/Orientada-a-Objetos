package atividade1;

import java.util.Scanner;

public class Netbook extends Computador {

	public Netbook(String marca) {
		super(marca);
	}
	
	public String exibeMarca() {
		return marca;
	}
	
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		
		System.out.print("Digite a marca do Netbook: ");
		String marca = scn.nextLine();
		
		Notebook net = new Notebook(marca);
		System.out.println("Modelo: "+net.exibeModelo());
		System.out.println("Marca: "+net.exibeMarca());
		
		scn.close();
	}

}
