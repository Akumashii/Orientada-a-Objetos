package atividade2;

public class Produto {
	protected double preco;
	protected double desconto;
	
	public double desconto() {
		return 0;
	}
	
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public double getDesconto() {
		return desconto;
	}

	public void setDesconto(double desconto) {
		this.desconto = desconto;
	}
}
