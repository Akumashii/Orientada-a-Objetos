package atividade2;

public class ProdutoComDesconto extends Produto{
	
	@Override
	public double desconto() {
		desconto = 0.5;
		return preco-(desconto*preco);
	}
}
