package atividade2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		ProdutoComDesconto p = new ProdutoComDesconto();
		
		System.out.print("Digite o preco do produto: ");
		p.setPreco(scn.nextDouble()); 
		
		System.out.println("Produto com desconto: "+p.desconto());
		
		scn.close();
	}

}
