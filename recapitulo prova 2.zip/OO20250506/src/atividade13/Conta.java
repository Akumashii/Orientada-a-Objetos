package atividade13;

import java.util.List;

public class Conta {
	private String titular;
	private int numero;
	private double saldo;
	
	public Conta(String titular, int numero, double saldo)
	{
		setTitular(titular);
		setNumero(numero);
		setSaldo(saldo);	
	}
	
	public void exibirDados() {
        System.out.println("Número da Conta: "+numero);
        System.out.println("Titular: "+titular);
        System.out.println("Saldo: R$ "+saldo);
        System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-");
    }
	
	public static int IndiceContaMaiorSaldo(List<Conta> contas)
	{
        double maior = contas.get(0).getSaldo();
        int index=0;
        for (int i=0; i<contas.size() ; i++) {
            if (contas.get(i).getSaldo() > maior) {
                maior = contas.get(i).getSaldo();
                index = i;
            }
        }
        return index;
    }
	
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	
	
}
