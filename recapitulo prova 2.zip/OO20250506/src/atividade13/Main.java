package atividade13;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/*
 * 13- Crie uma classe Conta com atributos numero, titular e saldo.
 *  Crie uma lista de contas e adicione algumas contas nessa lista.
 *  Em seguida, crie um método que recebe uma lista de contas e retorna a conta com o maior saldo.
 *	Por fim, chame esse método passando a lista de contas e imprima os dados 
 *	da conta com o maior saldo.
 * */

public class Main {

	public static void main(String[] args) {
		List<Conta> contas = new ArrayList<>();
		
		contas.add(new Conta("Frazzon", 1, 200.75));
		contas.add(new Conta("Luiza", 2, 3200000.0));
		contas.add(new Conta("Vanessa", 3, 28920.0));
		contas.add(new Conta("Rico", 4, 999999999.0));

		
		contas.sort(Comparator.comparing(Conta::getSaldo));
		//aqui ele ta ordenando baseado no saldo de cada um que ta na conta
				
		
		int indiceContaMaiorSaldo = Conta.IndiceContaMaiorSaldo(contas);
		System.out.println("Conta com maior saldo: ");
		contas.get(indiceContaMaiorSaldo).exibirDados();
	}
}
