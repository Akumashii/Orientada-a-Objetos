package atividade10;

import java.util.ArrayList;

/*
 * 10 - Crie uma classe Aluno com atributos nome, nota1 e nota2. Crie uma lista de
alunos e adicione alguns alunos nessa lista. Em seguida, percorra a lista e calcule a
média de cada aluno. Se a média for maior ou igual a 6, imprima que o aluno foi
aprovado. Caso contrário, imprima que o aluno foi reprovado.
 * */

public class Main 
{

	public static void main(String[] args) 
	{
		ArrayList<Aluno> alunos= new ArrayList<>();
		
		alunos.add(new Aluno("Frazzon", 5, 7));
		alunos.add(new Aluno("Vanesssa", 8, 9));
		alunos.add(new Aluno("Luiza", 10, 7));
		alunos.add(new Aluno("Lucas", 1.2, 3.2));

		for(Aluno a : alunos)
		{
			a.exibirResultado();
		}
	
	}

}
