package atividade7;

public class NotificacaoEmail extends Notificacao 
{
	@Override
    public void enviar(String mensagem) {
        System.out.println("Enviando e-mail para 1 destinatário: '"+mensagem+"'");
    }
	
	public void enviar(String mensagem, String...destinatarios) //cria uma lista de array flexivel conforme for adicionando gente
	//achei legal
	{
		System.out.println("Enviando e-mail para: ");
		for(String destinatario : destinatarios) 
		{
			System.out.println(" - "+destinatario+"");
		}	
		System.out.print("txt: '"+mensagem+"'");
	}
}
