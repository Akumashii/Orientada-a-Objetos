package atividade7;

public class Notificacao {
	
	public void enviar(String mensagem) 
	{
		System.out.println("Mensagem Enviada: '"+mensagem+"'");
	}
}
