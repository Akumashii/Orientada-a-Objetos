package atividade7;

public class Main {

	public static void main(String[] args) {
		NotificacaoApp na = new NotificacaoApp();
		NotificacaoEmail ne = new NotificacaoEmail();
		
 		na.enviar("teste notificacaoApp...");
		
 		ne.enviar("mensagem teste pra 1 destinatario");
 		ne.enviar("mensagem teste pra todes", "Frazzon@gmail.com", "Ana@gmail.com", "Lucas@gmail.com");
		
	}

}
