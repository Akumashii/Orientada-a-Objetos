package atividade7;

public class NotificacaoApp extends Notificacao
{
	public void enviar(String mensagem) //confesso que não entendi esse aqui
	{
		System.out.println("Você: "+mensagem);
	}
}
