package atividade9;

import java.util.Scanner;
import java.util.ArrayList;

/*
 9 - Crie uma classe Produto com atributos nome, preco e quantidade. Crie uma lista
de produtos e adicione alguns produtos nessa lista. Em seguida, percorra a lista e
imprima os dados de cada produto.
 */

public class Main {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		
		ArrayList<Produto> produtos = new ArrayList<>();
		Produto p;
		
		for(int i=0 ; i<3 ; i++)
		{
			System.out.print("Nome: ");
			String nome = scn.nextLine();
			System.out.print("Preço: ");
			double preco = scn.nextDouble();
			scn.nextLine(); //limpar buffer
			System.out.print("Quantidade: ");
			int quantidade = scn.nextInt();
			scn.nextLine(); //limpa buffer
			
			System.out.println("-=-=-=-=-=-");
			
			p = new Produto(nome, preco, quantidade);
			
			produtos.add(p);
		}
		
		
		System.out.println("\n\n");
		for(Produto produto : produtos) 
		{
			produto.exibirDados();
		}
		
		scn.close();
	}

}
