package atividade9;

public class Produto {
	private String nome;
	private double preco;
	private int quantidade;
	
	public Produto(String nome, double preco, int quantidade)
	{
		setNome(nome);
		setPreco(preco);
		setQuantidade(quantidade);
	}
	
	public void exibirDados() 
	{
		System.out.println("Nome: "+nome+" | Preco: "+preco+" | Quantidade: "+quantidade+"\t");
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	
}
