package atividade11;

import java.util.ArrayList;

/*
 * 11 - Crie uma classe Pessoa com atributos nome, idade e sexo. Crie uma lista de
pessoas e adicione algumas pessoas nessa lista. Em seguida, crie um método que
recebe uma lista de pessoas e retorna a quantidade de mulheres. Por fim, chame
esse método passando a lista de pessoas e imprima a quantidade de mulheres.
 * */

public class Main 
{

	public static void main(String[] args) 
	{
		ArrayList<Pessoa> pessoas = new ArrayList<>();
		
		
		pessoas.add(new Pessoa("Frazzon", 19, 'F'));
		pessoas.add(new Pessoa("Luiza", 20, 'F'));
		pessoas.add(new Pessoa("Vanessa", 22, 'F'));
		pessoas.add(new Pessoa("Lucas", 18, 'M'));
		pessoas.add(new Pessoa("Ana", 19, 'F'));
		pessoas.add(new Pessoa("Nathalia", 19, 'F'));

		
		int quantMulher;
		quantMulher = Pessoa.quantMulher(pessoas);
		
		System.out.println("Quantidade de mulher: "+ quantMulher);
		
	}

}
