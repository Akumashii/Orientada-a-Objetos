package atividade11;

import java.util.ArrayList;

public class Pessoa {
	private String nome;
	private int idade;
	private char genero;
	
	
	public Pessoa(String nome, int idade, char genero) {
		this.nome = nome;
		this.genero = genero;
		this.idade = idade;
	}

	public static int quantMulher(ArrayList<Pessoa> pessoas)
	{
		int cont = 0;
        for (Pessoa p : pessoas) {
            if (Character.toUpperCase(p.getGenero()) == 'F') {
                cont++;
            }
        }
		return cont;	
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public char getGenero() {
		return genero;
	}
	public void setGenero(char genero) {
		this.genero = genero;
	}
	
}
