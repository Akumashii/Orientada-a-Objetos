package atividade12;

import java.util.ArrayList;
import java.util.Comparator;
/*
 *  12-Crie uma classe Livro com atributos titulo, autor e ano. Crie uma lista de 
livros e adicione alguns livros nessa lista. Em seguida, ordene a lista de livros 
pelo ano de lançamento e imprima os dados de cada livro
 * */
public class Main {

	public static void main(String[] args) {
		ArrayList<Livro> livros = new ArrayList<>();
		
		livros.add(new Livro("Pequeno Príncipe", "Roberto Carlos", 2077));
		livros.add(new Livro("Sapiens", "Yuval Noah", 1217));
		livros.add(new Livro("Apito", "G. Frazzon", 1989));
		livros.add(new Livro("Abecedário", "Xuxa", 1888));
		livros.add(new Livro("Little Monster", "Lady Gaga", 3025));
		
		//fazer sorteamento
		livros.sort(Comparator.comparing(Livro::getAno));
		
		for(Livro l : livros)
		{
			l.exibirInfo();
		}
	}

}
