package atividade3;

public class Funcionario {
	protected double salario;
	protected int horasTrabalhadas;
	
	public void calcularSalario() {
		salario = horasTrabalhadas*5;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getHorasTrabalhadas() {
		return horasTrabalhadas;
	}

	public void setHorasTrabalhadas(int horasTrabalhadas) {
		this.horasTrabalhadas = horasTrabalhadas;
	}
	
}
