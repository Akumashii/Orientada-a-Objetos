package atividade3;

public class Main {

	public static void main(String[] args) {
		Gerente g = new Gerente();
		
		//pra poder calcular o salario preciso estabelecer as horas trabalhadas
		g.setHorasTrabalhadas(40);
		
		//imprime o resultado do salario do gerente
		g.calcularSalario();
	}

}
