package atividade3;

public class Gerente extends Funcionario{
	
	@Override
	public void calcularSalario() {
		salario = horasTrabalhadas*100;
		
		double bonus = salario*0.1;
		salario = salario + bonus;
		
		System.out.println("Salario gerente: "+salario);
	}
}
