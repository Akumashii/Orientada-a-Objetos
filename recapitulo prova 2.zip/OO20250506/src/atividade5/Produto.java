package atividade5;

public class Produto {
	private double preco;
	
	public void calcularPrecoFinal(double preco) {
		this.setPreco(preco);
	}
	public void calcularPrecoFinal(double preco, Cliente c) {
		this.setPreco(c.desconto(preco));
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
}
