package atividade5;

public class Main {

	public static void main(String[] args) {
		Produto p = new Produto();
		
		p.calcularPrecoFinal(500);
		System.out.println("preco: "+p.getPreco());
		
		Cliente c = new Cliente();
		p.calcularPrecoFinal(500, c);
		
		System.out.println("preco: "+p.getPreco());

	}

}
