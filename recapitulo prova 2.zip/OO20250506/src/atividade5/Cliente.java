package atividade5;

public class Cliente {
	private double desconto;

	public double desconto(double preco) {
		desconto = 0.5;
		return preco-(desconto*preco);
	}
}
