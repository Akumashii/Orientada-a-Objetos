package atividade1;

public class Triangulo extends FormaGeometrica{
	@Override
	public void calcularArea(double lado) {
		double area = (lado * lado)/2;
		System.out.println("Area Triangulo: "+area);
	}
}
