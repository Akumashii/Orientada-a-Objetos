package atividade1;
/*Crie uma classe FormaGeometrica com um método calcularArea(). 
 * Em seguida, crie uma classe Triangulo que herda da classe FormaGeometrica 
 * e sobrescreve o método calcularArea() para calcular a área do triângulo 
 * e imprimir o resultado.*/
public class Main {

	public static void main(String[] args) {
		Triangulo t = new Triangulo();
		
		t.calcularArea(3);
	}

}
