package atividade1;

public class FormaGeometrica {

	public void calcularArea(double lado) {
	}
}
