package atividade3;
/*Crie uma classe Pessoa com um método falar(String mensagem) que imprime a mensagem passada como parâmetro.
 *  Sobrecarregue o método falar() para aceitar uma mensagem 
 *  e um número de repetições 
 *  e imprimir a mensagem várias vezes.*/
public class Main {

	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		
		p.falar("lindeza");
		
		p.falar("blim blom pim", 5);
	}

}
