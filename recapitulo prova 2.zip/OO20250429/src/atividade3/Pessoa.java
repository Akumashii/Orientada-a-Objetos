package atividade3;

public class Pessoa {
	public void falar(String msg) {
		System.out.println(msg);
	}
	public void falar(String msg, int rep) {
		for(int i=0; i<rep; i++) {
			System.out.println(msg);
		}
	}
}
