package jogo_rapido2;

public class Pessoa {
	public void dizerOla() {
		System.out.println("Oiie");
	}
	public void dizerOla(String nome) {
		System.out.println("Olá! "+nome+", prazer.");
	}
}
