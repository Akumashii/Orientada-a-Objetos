package jogo_rapido2;

public class Main {

	public static void main(String[] args) {
		String nome = "Frazzon";
		
		Pessoa p = new Pessoa();
		p.dizerOla();
		p.dizerOla(nome);
		
	}

}
