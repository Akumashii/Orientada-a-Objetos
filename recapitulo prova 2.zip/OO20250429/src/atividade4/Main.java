package atividade4;
/* Crie uma classe Casa com um método calcularPreco(int tamanho) que retorna o preço da casa com base no tamanho em metros quadrados. 
 * Sobrecarregue o método calcularPreco() para aceitar um número de quartos 
 * e retornar o preço da casa com base no tamanho e no número de quartos*/
public class Main {

	public static void main(String[] args) {
		Casa c = new Casa();
		
		//metodo com 1 parametro
		c.calcularPreco(200);
	
		//metodo com 2 parametro
		c.calcularPreco(200, 1);
	}

}
