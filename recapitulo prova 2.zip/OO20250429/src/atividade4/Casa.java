package atividade4;

public class Casa {
	public void calcularPreco(int tamanho) {
		double preco = tamanho*5;
		System.out.println("Preco com base na metragem: "+preco);
	}
	public void calcularPreco(int tamanho, int numQuarto) {
		double preco = tamanho*5 + numQuarto*100;
		System.out.println("Preco com base na metragem e numero de quartos: "+ preco);
	}
}
