package sobrecarga;

public class Main {

	public static void main(String[] args) {
		int x=2, y=4, z=8;
		double a=1.0, b=5.3;
		
		Calculadora c = new Calculadora();
		System.out.println("Soma de x e y: "+c.somar(x, y));
		System.out.println("Soma de x, y e z: "+c.somar(x, y, z));
		
		double resultado = c.somar(a, b);
		System.out.println("Soma de a e b: "+resultado);
		
		System.out.println("--------------------------------");
		double r1 = c.multiplicar(7, 3);
		double r2 = c.multiplicar(2.5, 4.2);
		System.out.println("multi1: "+r1);
		System.out.println("multi2: "+r2);
		
		
	}

}
