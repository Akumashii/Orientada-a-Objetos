package atividade2;

public class ContaBancaria {
	protected double saldo;
	
	public ContaBancaria(double saldo) {
		this.saldo = saldo;
	}
	
	public void calcularSaldo(double saldo) {
	}
}
