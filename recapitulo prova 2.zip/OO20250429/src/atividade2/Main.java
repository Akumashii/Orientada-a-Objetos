package atividade2;
/*Crie uma classe ContaBancaria com um método calcularSaldo(). 
 * Em seguida, crie uma classe ContaCorrente que herda da classe ContaBancaria 
 * e sobrescreve o método calcularSaldo() para calcular o saldo da conta corrente 
 * e imprimir o resultado.*/
public class Main {

	public static void main(String[] args) {
		ContaCorrente c = new ContaCorrente(0);
		
		c.calcularSaldo(300);
		c.calcularSaldo(300);
		c.calcularSaldo(300);
		c.calcularSaldo(300);
		
	}

}
