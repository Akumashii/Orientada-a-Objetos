package atividade2;

public class ContaCorrente extends ContaBancaria{

	public ContaCorrente(double saldo) {
		super(saldo);
	}
	@Override
	public void calcularSaldo(double saldo) {
		this.saldo = this.saldo + saldo;
		System.out.println("Saldo: "+this.saldo);
	}
}
