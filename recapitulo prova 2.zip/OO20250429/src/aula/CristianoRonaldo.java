package aula;

public class CristianoRonaldo extends Animal{
	
	@Override
	public void emitirSom() {
		System.out.println("siiuuuuu");
	}
}
