package aula;

public class Main {

	public static void main(String[] args) {
		Animal a = new Animal();
		a.nome = "Animal 1";
		a.emitirSom();
		
		System.out.println("-----------------------------------");
		Cachorro c = new Cachorro();
		c.nome = "Bosta";
		c.raca = "Marrom";
		c.emitirSom();
		
		System.out.println("-----------------------------------");
		CristianoRonaldo cr = new CristianoRonaldo();
		cr.nome = "CR7";
		cr.emitirSom();
	}

}
