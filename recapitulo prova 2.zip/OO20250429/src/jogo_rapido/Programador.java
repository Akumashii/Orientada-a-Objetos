package jogo_rapido;

public class Programador extends Pessoa{
	
	@Override
	public void trabalhando() {
		System.out.println("Programando...");
	}
}
