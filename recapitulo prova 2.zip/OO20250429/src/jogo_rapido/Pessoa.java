package jogo_rapido;

public class Pessoa {
	public String nome;
	
	public void trabalhando() {
		System.out.println("Trabalha é cringe...");
	}
}
