package jogo_rapido;

public class Main {

	public static void main(String[] args) {
		Pessoa p;
		
		p = new Pessoa();
		p.nome = "Frazzon";
		System.out.print("Nome: "+p.nome+" | Status: ");
		p.trabalhando();

		p = new Programador();
		p.nome = "Frazzon";
		System.out.print("Nome: "+p.nome+" | Status: ");
		p.trabalhando();
		
	}

}

