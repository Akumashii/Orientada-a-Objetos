package jogoRapido;

public class Cachorro extends Animal {
	protected String raca;

	public String getRaca() {
		return raca;
	}

	public void setRaca(String raca) {
		this.raca = raca;
	}
	public void latir() {
		System.out.println(som);
	}
	
	public void exibirDados() {
		System.out.println("-=-=-=-=-=-=-=-=-=-=-");
		System.out.println("Nome: "+nome);
		System.out.println("Idade: "+idade);
		System.out.println("Raça: "+raca);
	}
	
}
