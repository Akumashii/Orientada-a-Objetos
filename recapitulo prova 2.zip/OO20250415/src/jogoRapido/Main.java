package jogoRapido;

public class Main {

	public static void main(String[] args) {
		Cachorro c = new Cachorro();
		
		c.setNome("bosta");
		c.setIdade(9);
		c.setSom("bahh tche");
		c.setRaca("guaipeca");
		
		System.out.print("Latido: ");
		c.latir();
	}

}
