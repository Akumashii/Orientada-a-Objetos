package pkg;

public class Main {

	public static void main(String[] args) {
		Onibus o = new Onibus();
		o.setNome("Marcopollo"); 
		o.setModelo("OF-1519");
		
		o.exibeMsg();
		
		System.out.println("\n\n");
		System.out.println("O nome do carro: "+o.getNome());
		System.out.println("Modelo do carro: "+o.getModelo());
		
	}

}
