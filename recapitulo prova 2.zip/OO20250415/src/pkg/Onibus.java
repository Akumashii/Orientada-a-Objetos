package pkg;

public class Onibus extends Carro {
	protected String Modelo;

	public String getModelo() {
		return Modelo;
	}

	public void setModelo(String modelo) {
		Modelo = modelo;
	}
	
	
}
