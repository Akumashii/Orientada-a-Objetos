package herancaMultipla;

public class Desenho2D extends Desenho{
	protected int altura;
	protected int largura;
	
	public Desenho2D(int largura, int altura){
		super();
		this.altura = altura;
		this.largura = largura;
	}
	
	public int getAltura() {
		return altura;
	}
	public void setAltura(int altura) {
		this.altura = altura;
	}
	public int getLargura() {
		return largura;
	}
	public void setLargura(int largura) {
		this.largura = largura;
	}
	
	
}
