package jogoRapido2;

public class PessoaJuridica extends Pessoa{
	protected String CNPJ;
	protected String socio;
	protected String dtAbertura;
	
	public PessoaJuridica(String nome, int idade, String CNPJ, String socio, String dtAbertura) {
		super(nome, idade);
		this.CNPJ = CNPJ;
		this.socio = socio;
		this.dtAbertura = dtAbertura;
	}
	
	public void exibeDados() {
		super.exibeDados();
		System.out.println("CNPJ: "+CNPJ);
		System.out.println("Socio: "+socio);
		System.out.println("dtAbertura: "+dtAbertura);
	}
	public String getCNPJ() {
		return CNPJ;
	}
	public void setCNPJ(String cNPJ) {
		CNPJ = cNPJ;
	}
	public String getSocio() {
		return socio;
	}
	public void setSocio(String socio) {
		this.socio = socio;
	}
	public String getDtAbertura() {
		return dtAbertura;
	}
	public void setDtAbertura(String dtAbertura) {
		this.dtAbertura = dtAbertura;
	}
	
	
}
