package jogoRapido2;

public class Main {

	public static void main(String[] args) {
		PessoaJuridica p = new PessoaJuridica("Frazzon",19,"cnpj fodasse","sociedade","sla oque é isso");
		
		p.exibeDados();
		
	}

}
