package herancaoMultiplaPrincipal;

import herancaMultipla.Quadrado;

public class PrincipalDesenho {

	public static void main(String[] args) {
		Quadrado d = new Quadrado(3,4,"legal");
		
		d.setNomeAutor("Frazzon");
		
		
		d.exibeDados();
		
	}

}
