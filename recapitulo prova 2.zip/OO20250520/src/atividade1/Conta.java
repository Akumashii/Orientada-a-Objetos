package atividade1;
/*
 * 1) Crie uma classe abstrata chamada Conta com as propriedades Saldo e Limite. 
 * Crie também métodos abstratos para Depositar e Sacar.
 * */
 public abstract class Conta {
	protected  double saldo;
	protected  double limite;
	
	public abstract void Depositar(double depositado);
	public abstract void Sacar(double saque);
	
	
	
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public double getLimite() {
		return limite;
	}
	public void setLimite(double limite) {
		this.limite = limite;
	}
 }
