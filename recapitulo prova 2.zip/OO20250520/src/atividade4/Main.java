package atividade4;

public class Main {

	public static void main(String[] args) {
		Carro carro = new Carro("Frazzon", "Rolim", 2006);
		Moto moto = new Moto("Ana","Senhor", 2006);
		
		carro.Acelerar();
		carro.Frear();
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-");
		moto.Acelerar();
		moto.Frear();
	}

}
