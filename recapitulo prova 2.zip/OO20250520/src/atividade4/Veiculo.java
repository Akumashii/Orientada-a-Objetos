package atividade4;

public abstract class Veiculo {
	public String marca;
	public String modelo;
	public int ano;
	
	public Veiculo(String marca, String modelo, int ano) 
	{
		this.marca = marca;
		this.modelo = modelo;
		this.ano = ano;
	}
	
	public abstract void Acelerar();
	public abstract void Frear();
}
