package interfaceExemplo1;

public class Cachorro implements Animal{
	public String nome;
	public int idade;
	
	public void emitirSom() 
	{
		System.out.println("AUU!!!");
	}
	public void exibeDados()
	{
		System.out.println(" -=- Cachorro! -=-");
		System.out.println("Nome: "+nome);
		System.out.println("Idade: "+idade);
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
}
