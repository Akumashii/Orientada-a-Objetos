package interfaceExemplo1;

public interface Animal {
	//posso APENAS declarar atributos CONSTANTES, que não sofreram alterações
	public int a = 10; //tipo isso aqui
	void emitirSom();
	void exibeDados();
}
