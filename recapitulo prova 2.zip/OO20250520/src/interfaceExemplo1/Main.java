package interfaceExemplo1;

public class Main {

	public static void main(String[] args) {
		Animal c = new Cachorro();
		Animal g = new Gato();

		c.emitirSom();
		System.out.println("= - = - =");
		g.emitirSom();
	}

}
