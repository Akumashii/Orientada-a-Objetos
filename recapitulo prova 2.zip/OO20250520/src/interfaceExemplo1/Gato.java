package interfaceExemplo1;

public class Gato implements Animal{
	public String nome;
	public String raca;
	
	public void emitirSom()
	{
		System.out.println("meeoww..");
	}

	@Override
	public void exibeDados() 
	{
		System.out.println(" -=- Gato! -=-");
		System.out.println("Nome: "+nome);
		System.out.println("Raça: "+raca);
		
	}
}
