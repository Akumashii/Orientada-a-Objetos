package atividade3;

import atividade2.Implementacao;

public class ContaInvestimento extends Implementacao{

	public ContaInvestimento(double Saldo, double Limite) {
		super(Saldo, Limite);
		// TODO Auto-generated constructor stub
	}
}
