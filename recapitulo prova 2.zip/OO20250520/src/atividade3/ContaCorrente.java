package atividade3;

import atividade2.Implementacao;

public class ContaCorrente extends Implementacao{

	public ContaCorrente(double Saldo, double Limite) {
		super(Saldo, Limite);
		// TODO Auto-generated constructor stub
	}
	
}
