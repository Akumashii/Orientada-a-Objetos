package atividade3;

public class Main {

	public static void main(String[] args) {
		ContaCorrente contaCorrente = new ContaCorrente(1000, 100);
		ContaInvestimento contaInvestimento = new ContaInvestimento(2000, 0);
		
		contaCorrente.Depositar(2);
		contaCorrente.Sacar(99);
		contaCorrente.Sacar(101);
		
		System.out.println("-=-=-=-=-=-=-=-=-=-");
		contaInvestimento.Depositar(9999);
		contaInvestimento.Sacar(10000);
	}
}
