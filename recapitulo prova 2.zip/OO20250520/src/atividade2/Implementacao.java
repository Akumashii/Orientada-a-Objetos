package atividade2;

import atividade1.Conta;

public class Implementacao extends Conta{
	public Implementacao(double Saldo, double Limite)
	{
		this.saldo = Saldo;
		this.limite = Limite;
	}
	
	public void Depositar(double depositado)
	{
		if(depositado <= 0)
			System.out.println("Erro: Depósito Negativo");
		else
		{
			saldo += depositado;
			System.out.println("Depósito Concluído!!");
		}
	}
	
	public void Sacar(double saque)
	{
		if(saque <= 0)
		{
			System.out.println("Erro: Saque Negativo");
		}
		else if(saldo - saque < -limite)
		{
			System.out.println("Erro: Saldo Insuficiente");
		}
		else
		{
			saldo -= saque;
			System.out.println("Saque Concluído!!");
		}
	}
}
