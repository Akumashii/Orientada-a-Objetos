package interfaceExemplo2;

import interfaceExemplo2.Pkg.Celular;
import interfaceExemplo2.Pkg.PC;

public class Smartphone implements PC, Celular{
	String tel;
	String email;
	
	public Smartphone(String tel, String email)
	{
		super();
		this.tel = tel;
		this.email = email;
	}
		
	@Override
	public void realizarChamada() {
		System.out.println("Realizando chamada");
		
	}

	@Override
	public void verificaEmail() {
		System.out.println("Verifica e-mails");
	}
	
}
