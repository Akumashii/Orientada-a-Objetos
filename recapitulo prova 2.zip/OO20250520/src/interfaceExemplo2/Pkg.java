package interfaceExemplo2;

public abstract class Pkg {
	interface PC
	{
		public void verificaEmail();
	}
	interface Celular
	{
		public void realizarChamada();
	}
}
