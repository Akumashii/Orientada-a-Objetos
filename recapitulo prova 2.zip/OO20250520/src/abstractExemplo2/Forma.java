package abstractExemplo2;

public abstract class Forma {
	public abstract double area(); //não precisa adicionar o public
	abstract double perimetro();//classe abstrata já é public
	//não faz sentido ter uma classe abstrata privada
	//pois sua função é ser herdada, se privar acabou né
	
	abstract void exibeDados();
}
