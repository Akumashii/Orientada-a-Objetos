package abstractExemplo2;

public class Retangulo extends Forma{
	private double largura;
	private double altura;
	
	public Retangulo(double largura, double altura)
	{
		this.largura = largura;
		this.altura = altura;
	}
	
	@Override
	public void exibeDados() 
	{
		System.out.println("largura: "+largura);
		System.out.println("altura: "+altura);
		System.out.println("area: "+area());
		System.out.println("perimetro: "+perimetro());
	}
	
	@Override
	public double area()
	{
		return largura * altura;
	}
	@Override
	public double perimetro()
	{
		return 2 * (largura + altura);
	}
}
