package abstractExemplo2;

public class Circulo extends Forma{
	private double raio;
	
	public Circulo(double raio)
	{
		this.raio = raio;
	}
	
	@Override
	public void exibeDados()
	{
		System.out.println("raio: "+raio);
		System.out.println("area: "+area());
		System.out.println("perimetro: "+perimetro());
	}
	
	@Override
	public double area()
	{
		return 3.14 * raio * raio;
	}
	@Override
	public double perimetro()
	{
		return 2 * 3.14 * raio;
	}
}
