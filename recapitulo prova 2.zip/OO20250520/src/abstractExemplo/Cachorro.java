package abstractExemplo;

public class Cachorro extends Animal{
	public String raca;
	
	@Override
	public void emitirSom() {
		System.out.println("AAAAAAAAAAAAAAAAAA");
	}
	
	@Override
	public void exibeDados() 
	{
		System.out.println("Espécie: "+especie);
		System.out.println("Idade: "+idade);
		System.out.println("Raça: "+raca);
	}
	
	public void cuidarPatio()
	{
		System.out.println("Estou no pátio resenha 👌👌😎😎");
	}

}
