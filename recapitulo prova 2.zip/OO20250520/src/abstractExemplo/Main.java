package abstractExemplo;

public class Main {

	public static void main(String[] args) {
		Cachorro c = new Cachorro();
		
		c.especie = "Frazzon";
		c.idade = 19;
		c.raca = "bosta";
		
		c.exibeDados();
		c.emitirSom();
		c.cuidarPatio();
	}

}
