package abstractExemplo;

abstract class Animal {
	public String especie;
	public int idade;
	abstract void emitirSom();

	public void exibeDados()
	{
		System.out.println("Espécie: "+especie);
		System.out.println("Idade: "+idade);
	}
}
