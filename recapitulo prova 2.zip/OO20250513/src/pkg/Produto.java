package pkg;

public class Produto {
	private String nome;
	private double preco;
	
	public Produto(String nome, double preco) {
		this.nome = nome;
		this.preco = preco;
	}
			
	/*
	public Produto clone() {
		return new Produto(this.nome, this.preco); 
	}
	*/
	// OU DA PRA USAR ASSIM PARA RETORNAR ELE MESMO:
	// SÃO MÉTODOS DIFERENTES
	public Produto clone() {
		return this; //PONTEIRO
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	
}
