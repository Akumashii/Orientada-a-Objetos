package pkg3;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		List<Pessoa> listaPessoa = new ArrayList<Pessoa>();
		
		Pessoa pessoa1 = new Pessoa("Frazzon", 19);
		Pessoa pessoa2 = new Pessoa("Luiza", 20);
		Pessoa pessoa3 = new Pessoa("Vanessa", 21);
		
		listaPessoa.add(pessoa1);
		listaPessoa.add(pessoa2);
		listaPessoa.add(pessoa3);
		
		exibirPessoas(listaPessoa);		
	}
	
	public static void exibirPessoas(List<Pessoa> lista)
	{
		for(Pessoa p : lista)
		{
			System.out.println("Nome: "+p.getNome());
			System.out.println("Idade: "+p.getIdade());
		}
	}
	public static void exibirPessoas2(List<Pessoa> lista)
	{
		for(int i=0; i<lista.size() ; i++)
		{
			System.out.println("Nome: "+lista.get(i).getNome());
			System.out.println("Idade: "+lista.get(i).getIdade());
		}
	}

}
