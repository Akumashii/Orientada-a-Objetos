package atividade1;

/*
 * 1 - Crie uma classe Aluno com os atributos nome e notaFinal. 
 * Em seguida, crie uma classe Boletim com um método imprimirStatus(Aluno a) 
 * que imprime se o aluno foi aprovado (nota = 6) ou reprovado.
 * */

public class Main {

	public static void main(String[] args) {
		
		double nota = 7;
		Aluno aluno = new Aluno("Frazzon", nota, new Boletim(nota));
		
		Boletim.imprimirStatus(aluno);
	}

}
