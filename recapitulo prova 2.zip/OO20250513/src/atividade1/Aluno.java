package atividade1;

public class Aluno {
	private String nome;
	private double notaFinal;
	private Boletim boletim;
	
	public Aluno(String nome, double notaFinal, Boletim boletim)
	{
		this.nome = nome;
		this.notaFinal = notaFinal;
		this.boletim = boletim;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getNotaFinal() {
		return notaFinal;
	}

	public void setNotaFinal(double notaFinal) {
		this.notaFinal = notaFinal;
	}

	public Boletim getBoletim() {
		return boletim;
	}

	public void setBoletim(Boletim boletim) {
		this.boletim = boletim;
	}
	
	
}
