package atividade1;

public class Boletim {
	private boolean aprovado;
	
	public Boletim(double notaFinal)
	{
		if(notaFinal >= 6.0)
		{
			setAprovado(true);
		}
		else 
		{
			setAprovado(false);
		}
	}
	
	public static void imprimirStatus(Aluno a)
	{
		System.out.println("Nota ("+a.getNome()+") - status da aprovação: ("+a.getBoletim().isAprovado()+")");
	}

	public boolean isAprovado() {
		return aprovado;
	}

	public void setAprovado(boolean aprovado) {
		this.aprovado = aprovado;
	}

}
