package atividade2;

/*
 * Crie uma classe Produto com os atributos nome e preco. 
 * Em outra classe, crie um método criarProdutoDesconto(String nome, double preco) 
 * que retorna um objeto Produto com 10% de desconto aplicado ao preço.
 * */

public class Main {
	public static Produto criarProdutoDesconto(String nome, double preco) {
        double precoComDesconto = preco * 0.9; // Aplica 10% de desconto
        return new Produto(nome, precoComDesconto);
    }

    // Exemplo de uso
    public static void main(String[] args) {
    	Produto produtoComDesconto = new Produto("Notebook", 3000.00);
    	System.out.println("Antes e Depois Desconto");
    	System.out.println("Nome: "+produtoComDesconto.getNome()+" // preço: "+produtoComDesconto.getPreco());
    	produtoComDesconto = criarProdutoDesconto(produtoComDesconto.getNome(), produtoComDesconto.getPreco());
        System.out.println("Nome: "+produtoComDesconto.getNome()+" // preço: "+produtoComDesconto.getPreco());
        
        
    }

}
