package atividade3;

import java.util.List;
import java.util.ArrayList;

/*
Crie uma classe Livro com os atributos titulo e autor. 
Em seguida, crie uma lista de livros (ArrayList) 
e um método que recebe a lista 
e imprime os dados de cada livro.
*/

public class Main {

	public static void main(String[] args) {
		List<Livro> livros = new ArrayList<>();
		
		livros.add(new Livro("Frazzon o grande", "Frazzon"));
		livros.add(new Livro("Contabilidade Inicial", "Ana Clara Nicoloso"));
		livros.add(new Livro("Bloons TD6", "Diabo"));

		
		for(Livro l : livros)
		{
			System.out.println("Titulo: "+l.getTitulo()+" // Autor: "+l.getAutor());
		}
	}

}
