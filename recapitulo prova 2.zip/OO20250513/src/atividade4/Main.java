package atividade4;

/*
 * Crie uma classe Conta com os atributos titular e saldo. 
 * Crie um método depositar(Conta c, double valor) 
 * que receba a conta como parâmetro e aumente o saldo.

 * */

public class Main {

	public static void main(String[] args) {
		Conta c = new Conta();
		
		c.setTitular("Frazzon");
		c.setSaldo(1000);
		
		
		System.out.println(" -=- Antes do depósito");		
		System.out.println("Nome: "+c.getTitular()+" // Saldo: "+c.getSaldo());
		
		System.out.println("-=- Depois do depósito");
		c.depositar(c,100.0);
		System.out.println("Nome: "+c.getTitular()+" // Saldo: "+c.getSaldo());		
	}

}
